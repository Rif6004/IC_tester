# Smart-IC-Tester

We all know what IC Testers do... but for those who don't - IC Testers are devices which are used to test Integrated Circuits by sending in Pulses as per their Truth Table. Generally, IC number is fed into IC Tester and a comparison test is made against that particular IC's Logic Table.

A smart IC tester is far more capable and better than a generic IC Tester, it has an ability to detect and check the connected IC along with a manual mode. Our IC Tester features a Touch LCD which gives a better user experience and easy to understand UI.

IC Testers maybe costly instrumentation devices but this one is just under ₹1600(~$22), pretty cheap right?

For full instructions on how to make your own Smart IC tester follow [instructables article](https://www.instructables.com/Smart-IC-Tester/).
